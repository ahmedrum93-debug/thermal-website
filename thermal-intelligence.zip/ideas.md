# Thermal Intelligence — Website Design Ideas

## Three Stylistic Approaches

### Approach A: Industrial Precision
**Theme Name:** Steel & Signal
**Brief:** A dark, high-contrast industrial aesthetic that mirrors the physical environments where HVAC systems operate — steel ducts, machine rooms, controlled precision. Deep charcoal backgrounds with electric teal accents and sharp geometric dividers.
**Probability:** 0.07

### Approach B: Corporate Engineering Authority ✅ CHOSEN
**Theme Name:** Blueprint Authority
**Brief:** A clean, authoritative B2B corporate identity rooted in the brand's own navy/teal palette. Asymmetric split layouts, bold oversized headings, and disciplined whitespace convey technical expertise and reliability without sacrificing warmth or approachability.
**Probability:** 0.09

### Approach C: Futuristic Climate Intelligence
**Theme Name:** Thermal Grid
**Brief:** A forward-looking, data-driven aesthetic with subtle grid overlays, glowing gradients, and animated data-flow motifs that position Thermal Intelligence as a technology company first, HVAC company second.
**Probability:** 0.04

---

## Chosen Approach: Blueprint Authority

### Design Movement
Corporate Engineering — the visual language of high-end B2B technical firms (think Siemens, Honeywell, ABB). Structured, trustworthy, and performance-oriented with a Saudi corporate sensibility.

### Core Principles
1. **Asymmetric authority** — headings break the grid intentionally; content blocks alternate left/right to create rhythm without monotony.
2. **Technical restraint** — no decorative flourishes; every visual element serves a functional or informational purpose.
3. **Color discipline** — the navy/teal palette from the PDF is preserved as the single ownable identity system; no competing hues.
4. **Scale contrast** — oversized display type paired with compact body text creates hierarchy and visual energy.

### Color Philosophy
The brand's existing palette is the anchor: deep navy (`#0D2B45`) for authority and depth, teal (`#1A7FA6`) for energy and precision, and clean white for breathing room. A warm off-white (`#F5F7F9`) replaces pure white for section backgrounds to avoid clinical sterility. Teal is used sparingly as an accent — borders, underlines, CTA buttons — never as a background fill for large areas.

| Role | Color | OKLCH |
|---|---|---|
| Primary Navy | `#0D2B45` | `oklch(0.20 0.06 230)` |
| Teal Accent | `#1A7FA6` | `oklch(0.52 0.10 220)` |
| Teal Light | `#2BA8D4` | `oklch(0.65 0.10 220)` |
| Off-white BG | `#F5F7F9` | `oklch(0.97 0.005 220)` |
| White | `#FFFFFF` | `oklch(1 0 0)` |
| Body Text | `#1C2B3A` | `oklch(0.22 0.04 230)` |

### Layout Paradigm
Sections use a **split-column asymmetry**: text on one side (60% width), visual proof on the other (40%), alternating per service. The hero uses a full-bleed image with a left-anchored content panel. The nav is sticky with a transparent-to-opaque scroll transition. Section transitions use diagonal clip-path cuts instead of flat horizontal dividers.

### Signature Elements
1. **Teal left-border accent** on section headings — a 4px solid teal line left of the section label, echoing the PDF's horizontal rule motif.
2. **Industrial number badges** — large faded navy numerals (01, 02, 03...) behind section headings as a structural motif.
3. **Quote panels** — dark navy panels with italic white text for key brand statements, directly mirroring the PDF's teal callout boxes.

### Interaction Philosophy
Interactions are deliberate and confident — no playful bounces. Hover states shift color rather than scale. Scroll-triggered entrance animations use a clean upward fade (translateY 20px → 0, opacity 0 → 1, 400ms ease-out). CTAs use a solid-to-outline inversion on hover.

### Animation
- Nav: background transitions from `transparent` to `rgba(13,43,69,0.95)` over 200ms on scroll.
- Section entrances: `opacity: 0; transform: translateY(24px)` → `opacity: 1; transform: translateY(0)` with 400ms ease-out, triggered by IntersectionObserver.
- Service cards: subtle border-color transition from `border-transparent` to `border-teal` on hover over 200ms.
- Supplier logos: grayscale → color on hover, 200ms ease.

### Typography System
- **Display headings (H1, H2):** `Barlow Condensed` — bold, wide, industrial. Uppercase for section labels, title-case for main headings.
- **Body and subheadings:** `Inter` — clean, readable, neutral. Used at 400 and 500 weights only.
- **Accent / quote text:** `Barlow Condensed` italic at medium weight for callout panels.
- H1: 72px / line-height 1.0 / letter-spacing -0.02em
- H2: 48px / line-height 1.1
- Section label: 13px uppercase / letter-spacing 0.12em / teal color
- Body: 16px / line-height 1.7

### Brand Essence
**Thermal Intelligence** — Saudi Arabia's engineering-led HVAC partner for clients who demand precision, reliability, and long-term performance. *Precise. Reliable. Engineered.*

### Brand Voice
Headlines are direct and declarative: "Engineered for Performance. Built to Last." CTAs are confident: "Discuss Your Project." No filler phrases like "Welcome" or "Get Started Today." Microcopy is technical but accessible: "Certified spare parts. Engineer-supervised execution."

### Wordmark & Logo
A stylized circular vortex mark (echoing the PDF's existing logo motif) in teal, paired with "THERMAL" in Barlow Condensed bold and "INTELLIGENCE" in a lighter weight below — creating a two-line wordmark with clear hierarchy.

### Signature Brand Color
**Teal `#1A7FA6`** — the unmistakable Thermal Intelligence accent that appears on every page as a border, underline, or button fill.
