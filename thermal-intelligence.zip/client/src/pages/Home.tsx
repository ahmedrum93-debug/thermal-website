/**
 * Thermal Intelligence — Home Page
 * Design: Blueprint Authority — Navy/Teal corporate engineering aesthetic
 * Fonts: Barlow Condensed (display) + Inter (body)
 * Colors: Navy oklch(0.20 0.06 230) | Teal oklch(0.52 0.10 220)
 */

import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import VisionMissionSection from "@/components/VisionMissionSection";
import ServicesSection from "@/components/ServicesSection";
import HSESection from "@/components/HSESection";
import SuppliersSection from "@/components/SuppliersSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <VisionMissionSection />
      <ServicesSection />
      <HSESection />
      <SuppliersSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
