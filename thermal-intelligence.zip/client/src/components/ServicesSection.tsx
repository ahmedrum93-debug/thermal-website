/**
 * ServicesSection — Thermal Intelligence
 * Four services with alternating split layouts, industrial photography
 * Design: Blueprint Authority — Navy/Teal
 */

import { Wind, Pipette, Wrench, Layers } from "lucide-react";

const services = [
  {
    id: "01",
    icon: Wind,
    title: "Air Conditioning & Cooling Solutions",
    description:
      "We provide specialized air conditioning and cooling services engineered for performance, efficiency, and long-term reliability. Our solutions are tailored to meet the specific demands of residential, commercial, and industrial environments — delivering consistent comfort and superior climate control.",
    highlights: [
      "VRF Systems (Variable Refrigerant Flow)",
      "Concealed Duct Systems",
      "Split Units",
      "Central Air Conditioning Systems",
    ],
    quote: "We don't just offer a service — we deliver a complete climate experience built on technical excellence and meticulous attention to detail.",
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=700&q=80&fit=crop",
  },
  {
    id: "02",
    icon: Layers,
    title: "Ductwork & Air Distribution Systems",
    description:
      "We provide end-to-end ductwork solutions engineered for high-performance air distribution. Our specialized engineering teams manage the full lifecycle of every ventilation system — from initial thermal studies and custom design through to professional on-site execution.",
    highlights: [
      "Comprehensive airflow evaluation and load calculations",
      "Tailored layouts optimized for space utilization and energy efficiency",
      "High-quality installation and sealing techniques that eliminate thermal loss",
    ],
    quote: "Every duct we install is a precision-engineered pathway for optimal air distribution.",
    image: "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=700&q=80&fit=crop",
  },
  {
    id: "03",
    icon: Wrench,
    title: "HVAC Maintenance Services",
    description:
      "We provide comprehensive maintenance services covering preventive, routine, and emergency needs — keeping every HVAC system operating at peak performance. Our maintenance services are built to sustain operational efficiency and deliver consistent, high-quality performance across residential, commercial, and industrial projects.",
    highlights: [
      "Preventive, routine, and emergency maintenance",
      "Certified, manufacturer-approved spare parts",
      "Engineer-supervised execution under international safety standards",
    ],
    quote: "Certified spare parts. Engineer-supervised execution. Zero compromise on performance.",
    image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=700&q=80&fit=crop",
  },
  {
    id: "04",
    icon: Pipette,
    title: "Copper Pipe Installation",
    description:
      "We provide professional copper pipe installation engineered to ensure seamless connection between indoor and outdoor AC units. Our work guarantees efficient refrigerant flow, optimal system performance, and long-term reliability — all in strict adherence to industry standards and best practices.",
    highlights: [
      "Materials compliant with approved technical specifications",
      "Qualified engineer supervision throughout installation",
      "Optimal refrigerant flow for both cooling and heating systems",
    ],
    quote: "Precision-installed copper piping — the backbone of a reliable, high-efficiency HVAC system.",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=700&q=80&fit=crop",
  },
];

export default function ServicesSection() {
  return (
    <section
      id="services"
      className="py-24"
      style={{ background: "oklch(0.97 0.005 220)" }}
    >
      <div className="container">
        {/* Header */}
        <div className="mb-16">
          <div className="flex items-center gap-2 mb-5">
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
            <span
              className="font-semibold uppercase tracking-widest"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.8125rem", letterSpacing: "0.12em", color: "oklch(0.52 0.10 220)" }}
            >
              What We Do
            </span>
          </div>
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
            <h2
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "clamp(2.25rem, 4vw, 3.25rem)",
                fontWeight: 700,
                color: "oklch(0.20 0.06 230)",
                lineHeight: 1.1,
                letterSpacing: "-0.01em",
                maxWidth: "520px",
              }}
            >
              Our Services
            </h2>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.9375rem",
                color: "oklch(0.50 0.04 230)",
                lineHeight: 1.7,
                maxWidth: "380px",
              }}
            >
              From design to maintenance, we cover every stage of your HVAC system's lifecycle with engineering precision.
            </p>
          </div>
        </div>

        {/* Services list */}
        <div className="space-y-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            const isEven = index % 2 === 1;
            return (
              <div
                key={service.id}
                className="rounded-lg overflow-hidden"
                style={{
                  background: "oklch(1 0 0)",
                  boxShadow: "0 1px 3px oklch(0.20 0.06 230 / 0.08), 0 4px 12px oklch(0.20 0.06 230 / 0.04)",
                  border: "1px solid oklch(0.88 0.01 220)",
                }}
              >
                <div className={`grid grid-cols-1 lg:grid-cols-5 ${isEven ? "" : ""}`}>
                  {/* Image */}
                  <div
                    className={`lg:col-span-2 relative overflow-hidden ${isEven ? "lg:order-last" : ""}`}
                    style={{ minHeight: "280px" }}
                  >
                    <img
                      src={service.image}
                      alt={service.title}
                      className="absolute inset-0 w-full h-full object-cover"
                      style={{ transition: "transform 0.5s cubic-bezier(0.23, 1, 0.32, 1)" }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLImageElement).style.transform = "scale(1.05)"; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLImageElement).style.transform = "scale(1)"; }}
                    />
                    {/* Dark gradient overlay */}
                    <div
                      className="absolute inset-0"
                      style={{ background: "linear-gradient(to top, oklch(0.14 0.05 230 / 0.7) 0%, transparent 60%)" }}
                    />
                    {/* Number overlay */}
                    <div
                      className="absolute bottom-4 left-4 font-bold text-white/30 select-none pointer-events-none leading-none"
                      style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "4.5rem" }}
                    >
                      {service.id}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="lg:col-span-3 p-8 lg:p-10 flex flex-col justify-between gap-6">
                    <div>
                      {/* Icon + Title */}
                      <div className="flex items-start gap-3 mb-4">
                        <div
                          className="w-10 h-10 rounded flex items-center justify-center flex-shrink-0 mt-0.5"
                          style={{ background: "oklch(0.52 0.10 220 / 0.1)" }}
                        >
                          <Icon size={20} style={{ color: "oklch(0.52 0.10 220)" }} />
                        </div>
                        <h3
                          style={{
                            fontFamily: "'Barlow Condensed', sans-serif",
                            fontSize: "clamp(1.25rem, 2.5vw, 1.625rem)",
                            fontWeight: 700,
                            color: "oklch(0.20 0.06 230)",
                            letterSpacing: "-0.01em",
                            lineHeight: 1.2,
                          }}
                        >
                          {service.title}
                        </h3>
                      </div>

                      {/* Description */}
                      <p
                        className="mb-5"
                        style={{
                          fontFamily: "'Inter', sans-serif",
                          fontSize: "0.9rem",
                          lineHeight: 1.75,
                          color: "oklch(0.42 0.04 230)",
                        }}
                      >
                        {service.description}
                      </p>

                      {/* Highlights */}
                      <ul className="space-y-2">
                        {service.highlights.map((h) => (
                          <li
                            key={h}
                            className="flex items-start gap-2.5"
                            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem", color: "oklch(0.35 0.04 230)" }}
                          >
                            <span
                              className="mt-2 flex-shrink-0 w-1.5 h-1.5 rounded-full"
                              style={{ background: "oklch(0.52 0.10 220)" }}
                            />
                            {h}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Quote */}
                    <div
                      className="rounded p-4"
                      style={{
                        background: "oklch(0.20 0.06 230)",
                        borderLeft: "3px solid oklch(0.52 0.10 220)",
                      }}
                    >
                      <p
                        style={{
                          fontFamily: "'Barlow Condensed', sans-serif",
                          fontSize: "1rem",
                          fontStyle: "italic",
                          color: "oklch(0.78 0.05 220)",
                          lineHeight: 1.5,
                        }}
                      >
                        {service.quote}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
