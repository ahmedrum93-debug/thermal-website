/**
 * SuppliersSection — Thermal Intelligence
 * Trusted supplier logo grid with styled brand name cards
 */

const suppliers = [
  { name: "Carrier", color: "#004B87", textColor: "#fff" },
  { name: "Mueller", color: "#003087", textColor: "#fff" },
  { name: "Trane", color: "#CC0000", textColor: "#fff" },
  { name: "York", color: "#003087", textColor: "#fff" },
  { name: "Midea", color: "#0066CC", textColor: "#fff" },
  { name: "Al-Asasyah", color: "#1A7FA6", textColor: "#fff" },
  { name: "Daikin", color: "#0073C2", textColor: "#fff" },
  { name: "Zamil AC", color: "#00843D", textColor: "#fff" },
];

export default function SuppliersSection() {
  return (
    <section
      id="suppliers"
      className="py-24"
      style={{ background: "oklch(1 0 0)" }}
    >
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-5">
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
            <span
              className="font-semibold uppercase tracking-widest"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.8125rem", letterSpacing: "0.12em", color: "oklch(0.52 0.10 220)" }}
            >
              Trusted Partners
            </span>
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
          </div>
          <h2
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2.25rem, 4vw, 3.25rem)",
              fontWeight: 700,
              color: "oklch(0.20 0.06 230)",
              lineHeight: 1.1,
              letterSpacing: "-0.01em",
            }}
          >
            Our Suppliers
          </h2>
          <p
            className="mt-4 mx-auto"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "0.9375rem",
              color: "oklch(0.50 0.04 230)",
              lineHeight: 1.7,
              maxWidth: "480px",
            }}
          >
            We partner with the world's leading HVAC manufacturers to deliver certified, high-performance equipment and components on every project.
          </p>
        </div>

        {/* Supplier grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {suppliers.map((supplier) => (
            <div
              key={supplier.name}
              className="flex items-center justify-center rounded-lg px-6 py-7 h-24 transition-all duration-200 cursor-default"
              style={{
                background: "oklch(0.97 0.005 220)",
                border: "1px solid oklch(0.88 0.01 220)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLDivElement).style.background = supplier.color;
                (e.currentTarget as HTMLDivElement).style.borderColor = supplier.color;
                const span = (e.currentTarget as HTMLDivElement).querySelector("span");
                if (span) span.style.color = supplier.textColor;
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLDivElement).style.background = "oklch(0.97 0.005 220)";
                (e.currentTarget as HTMLDivElement).style.borderColor = "oklch(0.88 0.01 220)";
                const span = (e.currentTarget as HTMLDivElement).querySelector("span");
                if (span) span.style.color = "oklch(0.28 0.06 230)";
              }}
            >
              <span
                className="font-bold text-center select-none"
                style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontSize: "1.25rem",
                  color: "oklch(0.28 0.06 230)",
                  letterSpacing: "0.04em",
                  transition: "color 0.2s ease",
                }}
              >
                {supplier.name}
              </span>
            </div>
          ))}
        </div>

        {/* Bottom note */}
        <p
          className="text-center mt-10"
          style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem", color: "oklch(0.60 0.04 230)" }}
        >
          All equipment and spare parts are certified and manufacturer-approved, ensuring full compatibility and optimal performance.
        </p>
      </div>
    </section>
  );
}
