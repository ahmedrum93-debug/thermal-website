/**
 * HeroSection — Thermal Intelligence
 * Full-bleed industrial HVAC background, left-anchored content panel
 */

import { useEffect, useRef } from "react";
import { ArrowRight, ChevronDown } from "lucide-react";

export default function HeroSection() {
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = contentRef.current;
    if (!el) return;
    const timer = setTimeout(() => {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToAbout = () => {
    document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ background: "oklch(0.14 0.05 230)" }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('/manus-storage/hero-hvac_fb481974.jpg')",
          backgroundPosition: "center 40%",
        }}
      />
      {/* Gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(105deg, oklch(0.14 0.05 230 / 0.92) 0%, oklch(0.14 0.05 230 / 0.75) 50%, oklch(0.14 0.05 230 / 0.4) 100%)",
        }}
      />

      {/* Content */}
      <div className="container relative z-10 pt-24 pb-20">
        <div
          ref={contentRef}
          style={{
            opacity: 0,
            transform: "translateY(32px)",
            transition: "opacity 0.7s cubic-bezier(0.23, 1, 0.32, 1), transform 0.7s cubic-bezier(0.23, 1, 0.32, 1)",
            maxWidth: "680px",
          }}
        >
          {/* Section label */}
          <div className="flex items-center gap-2 mb-6">
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block", flexShrink: 0 }} />
            <span
              className="text-white/70 font-semibold uppercase tracking-widest"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.8125rem", letterSpacing: "0.12em" }}
            >
              Dammam, Saudi Arabia
            </span>
          </div>

          {/* Main heading */}
          <h1
            className="text-white mb-6 leading-none"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(3rem, 7vw, 5.5rem)",
              fontWeight: 800,
              letterSpacing: "-0.01em",
              lineHeight: 1.0,
            }}
          >
            INTELLIGENT
            <br />
            <span style={{ color: "oklch(0.65 0.10 220)" }}>HVAC SOLUTIONS</span>
            <br />
            BUILT ON
            <br />
            PERFORMANCE
          </h1>

          {/* Subheading */}
          <p
            className="text-white/75 mb-10 leading-relaxed"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: "1.0625rem", maxWidth: "520px" }}
          >
            At Thermal Intelligence, we combine deep technical expertise with an uncompromising commitment to excellence — engineering forward-thinking, tailored HVAC solutions that maximize performance and minimize energy consumption.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => document.querySelector("#services")?.scrollIntoView({ behavior: "smooth" })}
              className="flex items-center gap-2 px-7 py-3.5 font-semibold rounded text-white transition-all duration-200"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                letterSpacing: "0.08em",
                fontSize: "0.9375rem",
                background: "oklch(0.52 0.10 220)",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.65 0.10 220)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.52 0.10 220)"; }}
            >
              OUR SERVICES <ArrowRight size={16} />
            </button>
            <button
              onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
              className="flex items-center gap-2 px-7 py-3.5 font-semibold rounded border text-white transition-all duration-200"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                letterSpacing: "0.08em",
                fontSize: "0.9375rem",
                borderColor: "rgba(255,255,255,0.4)",
                background: "transparent",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.borderColor = "white"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.4)"; }}
            >
              DISCUSS YOUR PROJECT
            </button>
          </div>

          {/* Stats row */}
          <div
            className="mt-14 pt-8 flex flex-wrap gap-8"
            style={{ borderTop: "1px solid oklch(1 0 0 / 0.12)" }}
          >
            {[
              { value: "30+", label: "Years Experience" },
              { value: "3", label: "Sectors Served" },
              { value: "100%", label: "Engineer Supervised" },
            ].map((stat) => (
              <div key={stat.label}>
                <div
                  className="text-white font-bold"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "2rem", lineHeight: 1 }}
                >
                  {stat.value}
                </div>
                <div
                  className="text-white/55 mt-1"
                  style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8125rem" }}
                >
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50 hover:text-white/80 transition-colors duration-200"
        aria-label="Scroll down"
      >
        <span style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.6875rem", letterSpacing: "0.12em" }}>SCROLL</span>
        <ChevronDown size={18} className="animate-bounce" />
      </button>
    </section>
  );
}
