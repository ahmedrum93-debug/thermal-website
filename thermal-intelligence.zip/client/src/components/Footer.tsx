/**
 * Footer — Thermal Intelligence
 * Dark navy footer with logo, navigation, and contact info
 */

import { Mail, Phone, MapPin, Globe } from "lucide-react";

const navLinks = [
  { label: "About", href: "#about" },
  { label: "Vision & Mission", href: "#vision" },
  { label: "Services", href: "#services" },
  { label: "Safety Policy", href: "#hse" },
  { label: "Suppliers", href: "#suppliers" },
  { label: "Contact", href: "#contact" },
];

const services = [
  "Air Conditioning & Cooling",
  "Ductwork & Air Distribution",
  "HVAC Maintenance",
  "Copper Pipe Installation",
];

export default function Footer() {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer style={{ background: "oklch(0.14 0.05 230)" }}>
      {/* Main footer content */}
      <div
        className="py-16"
        style={{ borderTop: "1px solid oklch(1 0 0 / 0.06)" }}
      >
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand column */}
            <div className="lg:col-span-1">
              <div className="flex items-center gap-3 mb-5">
                <img
                  src="/manus-storage/logo-icon_871ad143.png"
                  alt="Thermal Intelligence"
                  className="h-9 w-9 object-contain"
                />
                <div className="flex flex-col leading-none">
                  <span
                    className="font-bold text-white"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.0625rem", letterSpacing: "0.06em" }}
                  >
                    THERMAL
                  </span>
                  <span
                    className="font-medium text-white/50"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.65rem", letterSpacing: "0.18em" }}
                  >
                    INTELLIGENCE
                  </span>
                </div>
              </div>
              <p
                className="text-white/50 mb-6"
                style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem", lineHeight: 1.7 }}
              >
                Saudi Arabia's engineering-led HVAC partner — delivering intelligent solutions built on performance, precision, and reliability.
              </p>
              <div
                className="inline-flex items-center gap-2 px-4 py-2 rounded text-xs font-semibold"
                style={{
                  background: "oklch(0.52 0.10 220 / 0.12)",
                  border: "1px solid oklch(0.52 0.10 220 / 0.25)",
                  color: "oklch(0.65 0.10 220)",
                  fontFamily: "'Barlow Condensed', sans-serif",
                  letterSpacing: "0.06em",
                }}
              >
                VISION 2030 ALIGNED
              </div>
            </div>

            {/* Navigation */}
            <div>
              <h4
                className="text-white mb-5 font-semibold"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1rem", letterSpacing: "0.06em" }}
              >
                NAVIGATION
              </h4>
              <ul className="space-y-3">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    <button
                      onClick={() => scrollTo(link.href)}
                      className="text-white/50 hover:text-white transition-colors duration-200 text-left"
                      style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem" }}
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4
                className="text-white mb-5 font-semibold"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1rem", letterSpacing: "0.06em" }}
              >
                SERVICES
              </h4>
              <ul className="space-y-3">
                {services.map((s) => (
                  <li key={s}>
                    <button
                      onClick={() => scrollTo("#services")}
                      className="text-white/50 hover:text-white transition-colors duration-200 text-left"
                      style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem" }}
                    >
                      {s}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4
                className="text-white mb-5 font-semibold"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1rem", letterSpacing: "0.06em" }}
              >
                CONTACT
              </h4>
              <ul className="space-y-4">
                {[
                  { icon: Mail, value: "info@thermal.sa", href: "mailto:info@thermal.sa" },
                  { icon: Phone, value: "+966 55 156 3362", href: "tel:+966551563362" },
                  { icon: Globe, value: "www.thermal.sa", href: "https://www.thermal.sa" },
                  { icon: MapPin, value: "Dammam, Saudi Arabia", href: null },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <li key={item.value} className="flex items-start gap-3">
                      <Icon size={15} style={{ color: "oklch(0.52 0.10 220)", marginTop: "2px", flexShrink: 0 }} />
                      {item.href ? (
                        <a
                          href={item.href}
                          className="text-white/50 hover:text-white transition-colors duration-200"
                          style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem" }}
                        >
                          {item.value}
                        </a>
                      ) : (
                        <span
                          className="text-white/50"
                          style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.875rem" }}
                        >
                          {item.value}
                        </span>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div
        className="py-5"
        style={{ borderTop: "1px solid oklch(1 0 0 / 0.06)" }}
      >
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-3">
          <p
            className="text-white/30"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8125rem" }}
          >
            © {new Date().getFullYear()} Thermal Intelligence. All rights reserved.
          </p>
          <p
            className="text-white/30"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8125rem" }}
          >
            Dammam, Saudi Arabia
          </p>
        </div>
      </div>
    </footer>
  );
}
