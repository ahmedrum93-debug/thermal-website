/**
 * HSESection — Thermal Intelligence
 * Occupational Health & Safety Policy — dark navy with teal accents
 */

import { ShieldCheck, AlertTriangle, Users, BookOpen } from "lucide-react";

const pillars = [
  {
    icon: ShieldCheck,
    title: "Highest Safety Standards",
    desc: "Upholding the highest occupational health and safety standards across all HVAC projects in full compliance with local regulations and internationally recognized best practices.",
  },
  {
    icon: AlertTriangle,
    title: "Proactive Risk Management",
    desc: "Continuous risk assessment, proactive hazard identification and prevention, and strict adherence to personal protective equipment (PPE) requirements at every stage.",
  },
  {
    icon: Users,
    title: "Individual Responsibility",
    desc: "Ongoing safety training and awareness programs that build individual responsibility, reduce operational risk, and foster a strong safety culture at every level of the organization.",
  },
  {
    icon: BookOpen,
    title: "Embedded in Every System",
    desc: "Safety is not an add-on — it is embedded in how we design, execute, and maintain every system we deliver. Structured safety procedures are integrated into every stage of operations.",
  },
];

export default function HSESection() {
  return (
    <section
      id="hse"
      className="py-24 relative overflow-hidden"
      style={{ background: "oklch(0.14 0.05 230)" }}
    >
      {/* Background decoration */}
      <div
        className="absolute left-0 top-1/2 -translate-y-1/2 select-none pointer-events-none"
        style={{
          fontFamily: "'Barlow Condensed', sans-serif",
          fontSize: "20rem",
          fontWeight: 800,
          color: "oklch(1 0 0 / 0.025)",
          lineHeight: 1,
        }}
      >
        03
      </div>

      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left: heading and intro */}
          <div>
            <div className="inline-flex items-center gap-2 mb-5">
              <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
              <span
                className="font-semibold uppercase tracking-widest text-white/60"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.8125rem", letterSpacing: "0.12em" }}
              >
                HSE Policy
              </span>
            </div>
            <h2
              className="text-white mb-6"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "clamp(2.25rem, 4vw, 3.25rem)",
                fontWeight: 700,
                lineHeight: 1.1,
                letterSpacing: "-0.01em",
              }}
            >
              Occupational Health & Safety Policy
            </h2>
            <div
              className="space-y-4 text-white/65"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem", lineHeight: 1.75 }}
            >
              <p>
                At Thermal Intelligence, the health and safety of our people, clients, and work environments is a <strong className="text-white/90">core operational priority</strong>. We are committed to upholding the highest occupational health and safety standards across all HVAC projects and service operations.
              </p>
              <p>
                We maintain safe, controlled, and well-managed work environments by integrating structured safety procedures into every stage of our operations. This includes continuous risk assessment, proactive hazard identification and prevention, and strict adherence to PPE requirements.
              </p>
            </div>

            {/* HSE badge */}
            <div
              className="mt-10 inline-flex items-center gap-4 rounded-lg px-6 py-4"
              style={{ background: "oklch(0.52 0.10 220 / 0.15)", border: "1px solid oklch(0.52 0.10 220 / 0.3)" }}
            >
              <ShieldCheck size={28} style={{ color: "oklch(0.65 0.10 220)", flexShrink: 0 }} />
              <div>
                <div
                  className="text-white font-semibold"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1rem", letterSpacing: "0.04em" }}
                >
                  THERMAL INTELLIGENCE HSE POLICY
                </div>
                <div
                  className="text-white/50 text-xs mt-0.5"
                  style={{ fontFamily: "'Inter', sans-serif" }}
                >
                  Compliant with local regulations & international best practices
                </div>
              </div>
            </div>
          </div>

          {/* Right: four pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {pillars.map((pillar) => {
              const Icon = pillar.icon;
              return (
                <div
                  key={pillar.title}
                  className="rounded-lg p-6"
                  style={{
                    background: "oklch(0.20 0.06 230)",
                    border: "1px solid oklch(1 0 0 / 0.07)",
                    transition: "border-color 0.2s ease",
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.borderColor = "oklch(0.52 0.10 220 / 0.4)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.borderColor = "oklch(1 0 0 / 0.07)"; }}
                >
                  <div
                    className="w-10 h-10 rounded flex items-center justify-center mb-4"
                    style={{ background: "oklch(0.52 0.10 220 / 0.15)" }}
                  >
                    <Icon size={20} style={{ color: "oklch(0.65 0.10 220)" }} />
                  </div>
                  <h4
                    className="text-white mb-2"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.0625rem", fontWeight: 600 }}
                  >
                    {pillar.title}
                  </h4>
                  <p
                    className="text-white/55"
                    style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8375rem", lineHeight: 1.65 }}
                  >
                    {pillar.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
