/**
 * ContactSection — Thermal Intelligence
 * Dark background with contact details and inquiry form
 */

import { useState } from "react";
import { Mail, Phone, Globe, MapPin, ArrowRight, CheckCircle2 } from "lucide-react";

export default function ContactSection() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", company: "", email: "", phone: "", message: "" });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, this would send to a backend or email service
    setSubmitted(true);
  };

  const contactItems = [
    { icon: Mail, label: "Email", value: "info@thermal.sa", href: "mailto:info@thermal.sa" },
    { icon: Phone, label: "Phone", value: "+966 55 156 3362", href: "tel:+966551563362" },
    { icon: Globe, label: "Website", value: "www.thermal.sa", href: "https://www.thermal.sa" },
    { icon: MapPin, label: "Location", value: "Dammam, Saudi Arabia", href: null },
  ];

  return (
    <section
      id="contact"
      className="py-24 relative overflow-hidden"
      style={{ background: "oklch(0.20 0.06 230)" }}
    >
      {/* Background image overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-15"
        style={{ backgroundImage: "url('/manus-storage/contact-bg_88fb8074.jpg')" }}
      />
      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, oklch(0.20 0.06 230 / 0.95) 0%, oklch(0.14 0.05 230 / 0.85) 100%)" }} />

      <div className="container relative z-10">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-5">
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
            <span
              className="font-semibold uppercase tracking-widest text-white/60"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.8125rem", letterSpacing: "0.12em" }}
            >
              Reach Out
            </span>
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
          </div>
          <h2
            className="text-white"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2.25rem, 4vw, 3.25rem)",
              fontWeight: 700,
              lineHeight: 1.1,
              letterSpacing: "-0.01em",
            }}
          >
            Get In Touch
          </h2>
          <p
            className="mt-4 mx-auto text-white/60"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem", lineHeight: 1.7, maxWidth: "480px" }}
          >
            We're here to support you with expert advice and reliable service. Reach out for inquiries, consultations, or to discuss your next HVAC project.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact info */}
          <div className="flex flex-col justify-between">
            <div>
              <h3
                className="text-white mb-6"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.5rem", fontWeight: 600 }}
              >
                Contact Details
              </h3>
              <div className="space-y-4">
                {contactItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.label} className="flex items-center gap-4">
                      <div
                        className="w-11 h-11 rounded flex items-center justify-center flex-shrink-0"
                        style={{ background: "oklch(0.52 0.10 220 / 0.15)" }}
                      >
                        <Icon size={18} style={{ color: "oklch(0.65 0.10 220)" }} />
                      </div>
                      <div>
                        <div
                          className="text-white/40 text-xs mb-0.5"
                          style={{ fontFamily: "'Inter', sans-serif", letterSpacing: "0.08em", textTransform: "uppercase" }}
                        >
                          {item.label}
                        </div>
                        {item.href ? (
                          <a
                            href={item.href}
                            className="text-white hover:text-teal-300 transition-colors duration-200"
                            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem" }}
                          >
                            {item.value}
                          </a>
                        ) : (
                          <span
                            className="text-white"
                            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem" }}
                          >
                            {item.value}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Tagline */}
            <div
              className="mt-10 rounded-lg p-6"
              style={{ background: "oklch(0.52 0.10 220 / 0.12)", border: "1px solid oklch(0.52 0.10 220 / 0.25)" }}
            >
              <p
                className="italic text-white/80"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.125rem", lineHeight: 1.5 }}
              >
                "We are ready to help you move forward with confidence — from initial consultation to long-term maintenance support."
              </p>
            </div>
          </div>

          {/* Form */}
          <div
            className="rounded-lg p-8"
            style={{ background: "oklch(0.14 0.05 230 / 0.7)", border: "1px solid oklch(1 0 0 / 0.08)", backdropFilter: "blur(8px)" }}
          >
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full py-12 text-center">
                <CheckCircle2 size={48} style={{ color: "oklch(0.65 0.10 220)" }} className="mb-4" />
                <h4
                  className="text-white mb-2"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.5rem", fontWeight: 700 }}
                >
                  Message Received
                </h4>
                <p
                  className="text-white/60"
                  style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9rem" }}
                >
                  Thank you for reaching out. Our team will get back to you shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { name: "name", label: "Full Name", placeholder: "Your name", type: "text" },
                    { name: "company", label: "Company", placeholder: "Your company", type: "text" },
                  ].map((field) => (
                    <div key={field.name}>
                      <label
                        className="block mb-1.5 text-white/60 text-xs uppercase tracking-wider"
                        style={{ fontFamily: "'Inter', sans-serif" }}
                      >
                        {field.label}
                      </label>
                      <input
                        type={field.type}
                        name={field.name}
                        placeholder={field.placeholder}
                        value={form[field.name as keyof typeof form]}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded text-white placeholder-white/30 outline-none transition-all duration-200"
                        style={{
                          background: "oklch(0.20 0.06 230)",
                          border: "1px solid oklch(1 0 0 / 0.1)",
                          fontFamily: "'Inter', sans-serif",
                          fontSize: "0.9rem",
                        }}
                        onFocus={(e) => { (e.currentTarget as HTMLInputElement).style.borderColor = "oklch(0.52 0.10 220)"; }}
                        onBlur={(e) => { (e.currentTarget as HTMLInputElement).style.borderColor = "oklch(1 0 0 / 0.1)"; }}
                      />
                    </div>
                  ))}
                </div>
                {[
                  { name: "email", label: "Email Address", placeholder: "your@email.com", type: "email" },
                  { name: "phone", label: "Phone Number", placeholder: "+966 XX XXX XXXX", type: "tel" },
                ].map((field) => (
                  <div key={field.name}>
                    <label
                      className="block mb-1.5 text-white/60 text-xs uppercase tracking-wider"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      {field.label}
                    </label>
                    <input
                      type={field.type}
                      name={field.name}
                      placeholder={field.placeholder}
                      value={form[field.name as keyof typeof form]}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded text-white placeholder-white/30 outline-none transition-all duration-200"
                      style={{
                        background: "oklch(0.20 0.06 230)",
                        border: "1px solid oklch(1 0 0 / 0.1)",
                        fontFamily: "'Inter', sans-serif",
                        fontSize: "0.9rem",
                      }}
                      onFocus={(e) => { (e.currentTarget as HTMLInputElement).style.borderColor = "oklch(0.52 0.10 220)"; }}
                      onBlur={(e) => { (e.currentTarget as HTMLInputElement).style.borderColor = "oklch(1 0 0 / 0.1)"; }}
                    />
                  </div>
                ))}
                <div>
                  <label
                    className="block mb-1.5 text-white/60 text-xs uppercase tracking-wider"
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    Project Details
                  </label>
                  <textarea
                    name="message"
                    placeholder="Describe your HVAC project or inquiry..."
                    value={form.message}
                    onChange={handleChange}
                    rows={4}
                    required
                    className="w-full px-4 py-3 rounded text-white placeholder-white/30 outline-none transition-all duration-200 resize-none"
                    style={{
                      background: "oklch(0.20 0.06 230)",
                      border: "1px solid oklch(1 0 0 / 0.1)",
                      fontFamily: "'Inter', sans-serif",
                      fontSize: "0.9rem",
                    }}
                    onFocus={(e) => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = "oklch(0.52 0.10 220)"; }}
                    onBlur={(e) => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = "oklch(1 0 0 / 0.1)"; }}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3.5 rounded font-semibold text-white transition-all duration-200"
                  style={{
                    background: "oklch(0.52 0.10 220)",
                    fontFamily: "'Barlow Condensed', sans-serif",
                    fontSize: "1rem",
                    letterSpacing: "0.08em",
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.65 0.10 220)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.52 0.10 220)"; }}
                >
                  SEND INQUIRY <ArrowRight size={16} />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
