/**
 * AboutSection — Thermal Intelligence
 * Split layout: text left, industrial image right
 */

export default function AboutSection() {
  return (
    <section id="about" className="py-24" style={{ background: "oklch(1 0 0)" }}>
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Text column */}
          <div>
            <div className="section-label mb-5">About Our Company</div>
            <h2
              className="mb-6"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "clamp(2.25rem, 4vw, 3.25rem)",
                fontWeight: 700,
                color: "oklch(0.20 0.06 230)",
                lineHeight: 1.1,
                letterSpacing: "-0.01em",
              }}
            >
              Saudi Arabia's Engineering-Led HVAC Partner
            </h2>
            <div
              className="space-y-4"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem", lineHeight: 1.75, color: "oklch(0.35 0.04 230)" }}
            >
              <p>
                Thermal Intelligence is a Saudi-based company specializing in high-performance HVAC and air conditioning solutions. From concept to completion, we manage system design, installation, operation, and maintenance — serving residential, commercial, and industrial projects with a results-driven approach.
              </p>
              <p>
                Our work is built on precision, technical depth, and a commitment to getting it right the first time. Backed by a team of engineers and technicians with <strong style={{ color: "oklch(0.20 0.06 230)" }}>over 30 years of hands-on industry experience</strong>, we deliver practical expertise and disciplined execution on every project.
              </p>
              <p>
                We operate with a forward-looking mindset aligned with <strong style={{ color: "oklch(0.20 0.06 230)" }}>Saudi Vision 2030</strong>, contributing to sustainable development and building local capabilities through the growth of national talent and technical expertise.
              </p>
            </div>

            {/* Key values */}
            <div className="mt-10 grid grid-cols-2 gap-4">
              {[
                { label: "Performance-Driven", desc: "Every system optimized for peak output" },
                { label: "Energy Efficient", desc: "Minimizing consumption by design" },
                { label: "Tailored Solutions", desc: "No one-size-fits-all approach" },
                { label: "Vision 2030 Aligned", desc: "Sustainable, locally-built expertise" },
              ].map((item) => (
                <div
                  key={item.label}
                  className="p-4 rounded"
                  style={{ background: "oklch(0.97 0.005 220)", borderLeft: "3px solid oklch(0.52 0.10 220)" }}
                >
                  <div
                    className="font-semibold mb-1"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.9375rem", color: "oklch(0.20 0.06 230)", letterSpacing: "0.02em" }}
                  >
                    {item.label}
                  </div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8125rem", color: "oklch(0.50 0.04 230)" }}>
                    {item.desc}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Image column */}
          <div className="relative">
            <div
              className="absolute -top-4 -left-4 w-full h-full rounded-lg"
              style={{ background: "oklch(0.52 0.10 220 / 0.12)", zIndex: 0 }}
            />
            <div className="relative rounded-lg overflow-hidden" style={{ zIndex: 1 }}>
              <img
                src="/manus-storage/about-bg_8bd54e80.jpg"
                alt="HVAC installation by Thermal Intelligence"
                className="w-full h-auto object-cover"
                style={{ minHeight: "400px", objectFit: "cover" }}
              />
              {/* Overlay badge */}
              <div
                className="absolute bottom-6 left-6 right-6 rounded p-4"
                style={{ background: "oklch(0.20 0.06 230 / 0.92)", backdropFilter: "blur(8px)" }}
              >
                <p
                  className="italic text-white/90"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.0625rem", fontWeight: 500, lineHeight: 1.4 }}
                >
                  "We don't believe in one-size-fits-all solutions. Every system we deliver is tailored to specific operational needs."
                </p>
              </div>
            </div>
            {/* Decorative number */}
            <div
              className="absolute -right-6 -bottom-6 select-none pointer-events-none"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "8rem",
                fontWeight: 800,
                color: "oklch(0.20 0.06 230 / 0.06)",
                lineHeight: 1,
                zIndex: 0,
              }}
            >
              01
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
