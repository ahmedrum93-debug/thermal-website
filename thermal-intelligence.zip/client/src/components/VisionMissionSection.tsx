/**
 * VisionMissionSection — Thermal Intelligence
 * Dark navy background with two-column vision/mission cards
 */

import { Eye, Target } from "lucide-react";

export default function VisionMissionSection() {
  return (
    <section
      id="vision"
      className="py-24 relative overflow-hidden"
      style={{ background: "oklch(0.20 0.06 230)" }}
    >
      {/* Decorative background number */}
      <div
        className="absolute right-0 top-1/2 -translate-y-1/2 select-none pointer-events-none"
        style={{
          fontFamily: "'Barlow Condensed', sans-serif",
          fontSize: "20rem",
          fontWeight: 800,
          color: "oklch(1 0 0 / 0.03)",
          lineHeight: 1,
        }}
      >
        02
      </div>

      <div className="container relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-5">
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
            <span
              className="font-semibold uppercase tracking-widest text-white/60"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.8125rem", letterSpacing: "0.12em" }}
            >
              Our Direction
            </span>
            <span style={{ background: "oklch(0.52 0.10 220)", width: "3px", height: "1.25em", borderRadius: "2px", display: "inline-block" }} />
          </div>
          <h2
            className="text-white"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2.25rem, 4vw, 3.25rem)",
              fontWeight: 700,
              lineHeight: 1.1,
              letterSpacing: "-0.01em",
            }}
          >
            Vision & Mission
          </h2>
        </div>

        {/* Two columns */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Vision */}
          <div
            className="rounded-lg p-8 lg:p-10 relative overflow-hidden"
            style={{ background: "oklch(0.28 0.07 230)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            <div
              className="absolute top-6 right-6 opacity-10"
              style={{ color: "oklch(0.52 0.10 220)" }}
            >
              <Eye size={64} strokeWidth={1} />
            </div>
            <div
              className="inline-flex items-center justify-center w-12 h-12 rounded mb-6"
              style={{ background: "oklch(0.52 0.10 220 / 0.15)" }}
            >
              <Eye size={22} style={{ color: "oklch(0.65 0.10 220)" }} />
            </div>
            <h3
              className="text-white mb-4"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "1.875rem",
                fontWeight: 700,
                letterSpacing: "-0.01em",
              }}
            >
              Vision
            </h3>
            <div
              className="space-y-4 text-white/70"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem", lineHeight: 1.75 }}
            >
              <p>
                To be the leading provider of intelligent HVAC solutions across the Kingdom — recognized for performance-driven systems, exceptional service, and a deep understanding of our clients' operational needs.
              </p>
              <p>
                We strive to set a new industry benchmark through technical excellence, innovation, and clear communication.
              </p>
              <p>
                Aligned with Saudi Vision 2030, Thermal Intelligence is committed to driving sustainable growth, developing local expertise, and establishing itself as a trusted, forward-thinking leader in the HVAC industry.
              </p>
            </div>
          </div>

          {/* Mission */}
          <div
            className="rounded-lg p-8 lg:p-10 relative overflow-hidden"
            style={{ background: "oklch(0.52 0.10 220 / 0.12)", border: "1px solid oklch(0.52 0.10 220 / 0.25)" }}
          >
            <div
              className="absolute top-6 right-6 opacity-10"
              style={{ color: "oklch(0.65 0.10 220)" }}
            >
              <Target size={64} strokeWidth={1} />
            </div>
            <div
              className="inline-flex items-center justify-center w-12 h-12 rounded mb-6"
              style={{ background: "oklch(0.52 0.10 220 / 0.2)" }}
            >
              <Target size={22} style={{ color: "oklch(0.65 0.10 220)" }} />
            </div>
            <h3
              className="text-white mb-4"
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "1.875rem",
                fontWeight: 700,
                letterSpacing: "-0.01em",
              }}
            >
              Mission
            </h3>
            <div
              className="space-y-4 text-white/70"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9375rem", lineHeight: 1.75 }}
            >
              <p>
                At Thermal Intelligence, our mission is to deliver intelligent HVAC solutions that combine advanced engineering with real-world performance. We are dedicated to creating efficient, safe, and sustainable environments through systems designed to adapt, perform, and endure.
              </p>
              <p>
                Through precision, deep technical expertise, and disciplined execution, we deliver high-quality services that enhance comfort, optimize energy use, and ensure long-term operational reliability.
              </p>
              <p>
                We hold ourselves to the highest standards of performance, professionalism, and innovation — and we do not stop until we have exceeded our clients' expectations.
              </p>
            </div>
          </div>
        </div>

        {/* Vision 2030 badge */}
        <div
          className="mt-10 rounded-lg p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4"
          style={{ background: "oklch(0.14 0.05 230)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div
            className="flex-shrink-0 w-10 h-10 rounded flex items-center justify-center"
            style={{ background: "oklch(0.52 0.10 220)" }}
          >
            <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, color: "white", fontSize: "0.75rem", letterSpacing: "0.04em" }}>2030</span>
          </div>
          <p
            className="text-white/60"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9rem", lineHeight: 1.6 }}
          >
            <strong className="text-white/90">Saudi Vision 2030 Aligned:</strong> Thermal Intelligence actively contributes to the Kingdom's sustainable development agenda by building national talent, advancing local technical capabilities, and delivering energy-efficient solutions that support a greener future.
          </p>
        </div>
      </div>
    </section>
  );
}
