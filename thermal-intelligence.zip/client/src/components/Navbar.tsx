/**
 * Navbar — Thermal Intelligence
 * Transparent → opaque navy on scroll, smooth transition
 */

import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "About", href: "#about" },
  { label: "Vision & Mission", href: "#vision" },
  { label: "Services", href: "#services" },
  { label: "Safety", href: "#hse" },
  { label: "Suppliers", href: "#suppliers" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled
          ? "oklch(0.20 0.06 230 / 0.97)"
          : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        boxShadow: scrolled ? "0 1px 0 oklch(0.28 0.07 230)" : "none",
      }}
    >
      <div className="container flex items-center justify-between h-16 md:h-20">
        {/* Logo */}
        <a
          href="#"
          className="flex items-center gap-3 group"
          onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}
        >
          <img
            src="/manus-storage/logo-icon_871ad143.png"
            alt="Thermal Intelligence"
            className="h-9 w-9 object-contain"
          />
          <div className="flex flex-col leading-none">
            <span
              className="font-bold tracking-wide text-white"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.125rem", letterSpacing: "0.06em" }}
            >
              THERMAL
            </span>
            <span
              className="font-medium text-white/70"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "0.7rem", letterSpacing: "0.18em" }}
            >
              INTELLIGENCE
            </span>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNav(link.href)}
              className="text-white/80 hover:text-white transition-colors duration-200 text-sm font-medium tracking-wide"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => handleNav("#contact")}
            className="ml-2 px-5 py-2 text-sm font-semibold rounded transition-all duration-200 border"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              letterSpacing: "0.08em",
              background: "oklch(0.52 0.10 220)",
              borderColor: "oklch(0.52 0.10 220)",
              color: "white",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = "transparent";
              (e.currentTarget as HTMLButtonElement).style.color = "oklch(0.65 0.10 220)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.52 0.10 220)";
              (e.currentTarget as HTMLButtonElement).style.color = "white";
            }}
          >
            GET IN TOUCH
          </button>
        </nav>

        {/* Mobile toggle */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div
          className="md:hidden border-t"
          style={{
            background: "oklch(0.14 0.05 230)",
            borderColor: "oklch(0.28 0.07 230)",
          }}
        >
          <nav className="container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNav(link.href)}
                className="text-left py-3 px-2 text-white/80 hover:text-white border-b text-sm font-medium transition-colors"
                style={{ borderColor: "oklch(0.28 0.07 230 / 0.5)", fontFamily: "'Inter', sans-serif" }}
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => handleNav("#contact")}
              className="mt-3 py-3 px-4 text-sm font-semibold rounded text-white text-center"
              style={{ background: "oklch(0.52 0.10 220)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.08em" }}
            >
              GET IN TOUCH
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
